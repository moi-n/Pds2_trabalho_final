var searchData=
[
  ['enable_5fif_0',['enable_if',['../structdoctest_1_1detail_1_1types_1_1enable__if.html',1,'doctest::detail::types']]],
  ['enable_5fif_3c_20true_2c_20t_20_3e_1',['enable_if&lt; true, T &gt;',['../structdoctest_1_1detail_1_1types_1_1enable__if_3_01true_00_01_t_01_4.html',1,'doctest::detail::types']]],
  ['encontrabarco_2',['encontraBarco',['../class_batalha_naval.html#a6d0bb023c1c58b4bc2efa30b2b5313eb',1,'BatalhaNaval']]],
  ['enum_3',['Enum',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92',1,'doctest::Color::Enum'],['../namespacedoctest_1_1assert_type.html#ae1bb5bed722f34f1c38b83cb19d326d3',1,'doctest::assertType::Enum'],['../namespacedoctest_1_1detail_1_1binary_assert_comparison.html#a2117cafa5b007d26f2e0988f3a081569',1,'doctest::detail::binaryAssertComparison::Enum'],['../namespacedoctest_1_1detail_1_1assert_action.html#a38ba820518d42da988fab24b2f3d0548',1,'doctest::detail::assertAction::Enum'],['../namespacedoctest_1_1_test_case_failure_reason.html#aecb2ca1f80416d60f0d6b96f65859d3c',1,'doctest::TestCaseFailureReason::Enum']]],
  ['epsilon_4',['epsilon',['../structdoctest_1_1_approx.html#a3a9093777280fcf5fd79e79b1c202ba8',1,'doctest::Approx']]],
  ['eq_5',['eq',['../namespacedoctest_1_1detail_1_1binary_assert_comparison.html#a2117cafa5b007d26f2e0988f3a081569af644d2e3091c342ab78b12da1fcb06dc',1,'doctest::detail::binaryAssertComparison']]],
  ['error_5fstring_6',['error_string',['../structdoctest_1_1_test_case_exception.html#a656c8971ccbedc7d3a0a38f7c6af927e',1,'doctest::TestCaseException']]],
  ['estado_7',['estado',['../class_casa.html#a7ad1b1c4520cee73b77e8a9cf4b3968c',1,'Casa']]],
  ['exception_8',['Exception',['../namespacedoctest_1_1_test_case_failure_reason.html#aecb2ca1f80416d60f0d6b96f65859d3ca0474331a35ec33aefa287574dbe9a142',1,'doctest::TestCaseFailureReason']]],
  ['exceptiontranslator_9',['ExceptionTranslator',['../classdoctest_1_1detail_1_1_exception_translator.html',1,'doctest::detail::ExceptionTranslator&lt; T &gt;'],['../classdoctest_1_1detail_1_1_exception_translator.html#a3ac05488993c40c6ba55ce51a6bf7eae',1,'doctest::detail::ExceptionTranslator::ExceptionTranslator()']]],
  ['exit_10',['exit',['../structdoctest_1_1_context_options.html#a85d785559ea88e0bd61890f77f00a82f',1,'doctest::ContextOptions']]],
  ['expression_5flhs_11',['Expression_lhs',['../structdoctest_1_1detail_1_1_expression__lhs.html',1,'doctest::detail::Expression_lhs&lt; L &gt;'],['../structdoctest_1_1detail_1_1_expression__lhs.html#ab5d05d371e81dd7724592174afbfeba1',1,'doctest::detail::Expression_lhs::Expression_lhs()']]],
  ['expressiondecomposer_12',['ExpressionDecomposer',['../structdoctest_1_1detail_1_1_expression_decomposer.html',1,'doctest::detail::ExpressionDecomposer'],['../structdoctest_1_1detail_1_1_expression_decomposer.html#a6bf2c46ebf0dc68106be801a90776e65',1,'doctest::detail::ExpressionDecomposer::ExpressionDecomposer()']]],
  ['extremidades_13',['extremidades',['../class_barco.html#a5731aa2a8fbba8a0f5d45cf4a968b0ca',1,'Barco']]]
];
