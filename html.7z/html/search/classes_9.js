var searchData=
[
  ['jogador_0',['Jogador',['../class_jogador.html',1,'']]],
  ['jogodavelha_1',['JogodaVelha',['../class_jogoda_velha.html',1,'']]]
];
