var searchData=
[
  ['view_0',['view',['../structdoctest_1_1_string_1_1view.html',1,'doctest::String']]]
];
