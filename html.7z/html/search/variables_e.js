var searchData=
[
  ['p_0',['p',['../classdoctest_1_1_context.html#a1e22f778caf173478623e22546d7b493',1,'doctest::Context']]],
  ['partesatingidas_1',['partesAtingidas',['../class_barco.html#a4f5a86ebea7aac0d13dd40e75e8d3115',1,'Barco']]],
  ['posicionado_2',['posicionado',['../class_barco.html#ad128a65cce624d7fb60fc3c4d8ff00e1',1,'Barco']]],
  ['ptr_3',['ptr',['../structdoctest_1_1_string_1_1view.html#a18a399abb1e4be67bcc6d6557837a98c',1,'doctest::String::view']]],
  ['pulajogada_4',['pulaJogada',['../class_reversi.html#af9f56e639bad17aed3606df6011152d5',1,'Reversi']]]
];
