var searchData=
[
  ['approx_0',['Approx',['../structdoctest_1_1_approx.html',1,'doctest']]],
  ['assertdata_1',['AssertData',['../structdoctest_1_1_assert_data.html',1,'doctest']]]
];
