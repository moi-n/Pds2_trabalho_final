var searchData=
[
  ['y_0',['y',['../class_ponto.html#a50c1d80b0bf536d4c29dc5109f4e19b3',1,'Ponto']]]
];
