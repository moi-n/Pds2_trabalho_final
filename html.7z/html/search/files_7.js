var searchData=
[
  ['reversi_2ehpp_0',['reversi.hpp',['../reversi_8hpp.html',1,'']]]
];
