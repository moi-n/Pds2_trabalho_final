var searchData=
[
  ['value_0',['value',['../structdoctest_1_1detail_1_1types_1_1true__type.html#a5ad232af56ff87690d552f77e0413f02',1,'doctest::detail::types::true_type::value'],['../structdoctest_1_1detail_1_1types_1_1false__type.html#a8580f67f4b223b10e49d93b959767f6d',1,'doctest::detail::types::false_type::value'],['../structdoctest_1_1detail_1_1types_1_1is__enum.html#a2ac322024808b91cda5ce1a42691ee07',1,'doctest::detail::types::is_enum::value'],['../structdoctest_1_1detail_1_1should__stringify__as__underlying__type.html#a0115e8b2c73fe1a0fc9f344a1374e2dd',1,'doctest::detail::should_stringify_as_underlying_type::value'],['../structdoctest_1_1_is_na_n.html#a6a490d3d5f5561bcf019fefc88291475',1,'doctest::IsNaN::value']]],
  ['vencedor_1',['vencedor',['../class_tabuleiro.html#aacb989ac61b908ea52ddab89b45b6ffb',1,'Tabuleiro']]],
  ['verificacaptura_2',['verificaCaptura',['../class_tabuleiro_damas.html#a4bbb434b832c2600a4a4220fe56a7c73',1,'TabuleiroDamas']]],
  ['verificacoluna_3',['verificaColuna',['../class_reversi.html#a48752d01f4b16ef89bdf7611e738e2c0',1,'Reversi']]],
  ['verificadiagonal_4',['verificaDiagonal',['../class_reversi.html#affa226d04a93c34193dc28310b86def7',1,'Reversi']]],
  ['verificajogada_5',['verificaJogada',['../class_tabuleiro_damas.html#ace0cb511cf3479cb8f2af98590577f3c',1,'TabuleiroDamas']]],
  ['verificalinha_6',['verificaLinha',['../class_reversi.html#a000993146e8071ae7d9cbc014aa7960b',1,'Reversi']]],
  ['version_7',['version',['../structdoctest_1_1_context_options.html#a08931527a9e5e634e64a336e5493a7c1',1,'doctest::ContextOptions']]],
  ['vetor_5fbarcos_8',['vetor_barcos',['../class_batalha_naval.html#a0b9f0454f4002fb853b126f642ee6936',1,'BatalhaNaval']]],
  ['vetor_5ftabuleiros_9',['vetor_tabuleiros',['../class_batalha_naval.html#a42bd49b4dfbb56ed20084098385c6523',1,'BatalhaNaval']]],
  ['view_10',['view',['../structdoctest_1_1_string_1_1view.html',1,'doctest::String']]]
];
