var searchData=
[
  ['tabuleiro_0',['Tabuleiro',['../class_tabuleiro.html',1,'']]],
  ['tabuleirodamas_1',['TabuleiroDamas',['../class_tabuleiro_damas.html',1,'']]],
  ['tabuleirofileira_2',['TabuleiroFileira',['../class_tabuleiro_fileira.html',1,'']]],
  ['testcase_3',['TestCase',['../structdoctest_1_1detail_1_1_test_case.html',1,'doctest::detail']]],
  ['testcasedata_4',['TestCaseData',['../structdoctest_1_1_test_case_data.html',1,'doctest']]],
  ['testcaseexception_5',['TestCaseException',['../structdoctest_1_1_test_case_exception.html',1,'doctest']]],
  ['testfailureexception_6',['TestFailureException',['../structdoctest_1_1detail_1_1_test_failure_exception.html',1,'doctest::detail']]],
  ['testrunstats_7',['TestRunStats',['../structdoctest_1_1_test_run_stats.html',1,'doctest']]],
  ['testsuite_8',['TestSuite',['../structdoctest_1_1detail_1_1_test_suite.html',1,'doctest::detail']]],
  ['true_5ftype_9',['true_type',['../structdoctest_1_1detail_1_1types_1_1true__type.html',1,'doctest::detail::types']]],
  ['tuple_10',['tuple',['../classstd_1_1tuple.html',1,'std']]]
];
