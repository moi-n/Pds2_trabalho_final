var searchData=
[
  ['makecontextscope_0',['MakeContextScope',['../namespacedoctest_1_1detail.html#af15c2ff0484248d0966fc38a4b0d3a66',1,'doctest::detail']]],
  ['messagebuilder_1',['MessageBuilder',['../structdoctest_1_1detail_1_1_message_builder.html#a93cb6f180968d38cb0f18b08ec6c9000',1,'doctest::detail::MessageBuilder::MessageBuilder(const char *file, int line, assertType::Enum severity)'],['../structdoctest_1_1detail_1_1_message_builder.html#ae40185a1fbaf07becd0bd077806f0358',1,'doctest::detail::MessageBuilder::MessageBuilder(const MessageBuilder &amp;)=delete'],['../structdoctest_1_1detail_1_1_message_builder.html#a1b5690556dd0fc3ac24c998f49b96147',1,'doctest::detail::MessageBuilder::MessageBuilder(MessageBuilder &amp;&amp;)=delete']]],
  ['mudaconteudocasa_2',['mudaConteudoCasa',['../class_tabuleiro_damas.html#a17c5bf006556d628df613fed25869c6b',1,'TabuleiroDamas']]]
];
