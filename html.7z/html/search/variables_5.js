var searchData=
[
  ['failure_5fflags_0',['failure_flags',['../structdoctest_1_1_current_test_case_stats.html#aaa58c52fd07a20e6e4daf19eecb2e2ba',1,'doctest::CurrentTestCaseStats']]],
  ['fase_5fjogo_1',['fase_jogo',['../class_batalha_naval.html#a420bd7bfb528dafee688fe8afe830a26',1,'BatalhaNaval']]],
  ['first_2',['first',['../structdoctest_1_1_context_options.html#a9f26ee60a5259e73f9f25ce3f4883a97',1,'doctest::ContextOptions']]],
  ['flipped_3',['flipped',['../structdoctest_1_1_is_na_n.html#a3c25335f2708d9360b8e92813b3ac17d',1,'doctest::IsNaN']]],
  ['force_5fcolors_4',['force_colors',['../structdoctest_1_1_context_options.html#a8cd276e86a209f3d5486eb6c5a2a29bf',1,'doctest::ContextOptions']]]
];
