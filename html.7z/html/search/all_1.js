var searchData=
[
  ['barco_0',['Barco',['../class_barco.html',1,'Barco'],['../class_barco.html#aea54a1f00318af549e695999ccf08e38',1,'Barco::Barco()'],['../class_barco.html#a99cc8669abad6a2ecbec5faf75486120',1,'Barco::Barco(int tamanho, int id)']]],
  ['barco_2ehpp_1',['barco.hpp',['../barco_8hpp.html',1,'']]],
  ['basic_5fistream_2',['basic_istream',['../classstd_1_1basic__istream.html',1,'std']]],
  ['basic_5fostream_3',['basic_ostream',['../classstd_1_1basic__ostream.html',1,'std']]],
  ['batalhanaval_4',['BatalhaNaval',['../class_batalha_naval.html',1,'BatalhaNaval'],['../class_batalha_naval.html#abd37f9b78e4d8fc029bd22b43220c26b',1,'BatalhaNaval::BatalhaNaval()'],['../class_batalha_naval.html#a970c6ec8c072cd1a3079e392e9d5a549',1,'BatalhaNaval::BatalhaNaval(int num_linhas, int num_colunas)']]],
  ['batalhanaval_2ehpp_5',['batalhanaval.hpp',['../batalhanaval_8hpp.html',1,'']]],
  ['binary_5fassert_6',['binary_assert',['../structdoctest_1_1detail_1_1_result_builder.html#aa920a0617a26939d7adcd1ba2dec0e85',1,'doctest::detail::ResultBuilder::binary_assert()'],['../namespacedoctest_1_1detail.html#a1e295c708d2de0e47ac89c1632211159',1,'doctest::detail::binary_assert()']]],
  ['binary_5fname_7',['binary_name',['../structdoctest_1_1_context_options.html#a0590006b4d10296c9a697e32ff886f74',1,'doctest::ContextOptions']]],
  ['blue_8',['Blue',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92aada3ad8958b1319450cc20f3f8e5e2d6',1,'doctest::Color']]],
  ['bright_9',['Bright',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a7659647d16a78c607f9bafaa207b9e07',1,'doctest::Color']]],
  ['brightgreen_10',['BrightGreen',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a016090b96620a42a63dadf0265977664',1,'doctest::Color']]],
  ['brightred_11',['BrightRed',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a236dfdbcd49d10dbf1a31f9e2947a671',1,'doctest::Color']]],
  ['brightwhite_12',['BrightWhite',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a4f80853796b4875d61ff5e4ad138492e',1,'doctest::Color']]],
  ['buf_13',['buf',['../classdoctest_1_1_string.html#a7e031ced488588936a540eba26facf67',1,'doctest::String']]]
];
