var searchData=
[
  ['gomoku_0',['Gomoku',['../class_gomoku.html',1,'']]]
];
