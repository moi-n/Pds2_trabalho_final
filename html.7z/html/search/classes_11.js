var searchData=
[
  ['underlying_5ftype_0',['underlying_type',['../structdoctest_1_1detail_1_1types_1_1underlying__type.html',1,'doctest::detail::types']]]
];
