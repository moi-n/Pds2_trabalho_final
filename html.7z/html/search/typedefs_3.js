var searchData=
[
  ['nullptr_5ft_0',['nullptr_t',['../namespacestd.html#a147badd87f1e15108e8dbee257b60b84',1,'std']]]
];
