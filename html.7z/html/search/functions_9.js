var searchData=
[
  ['lig4_0',['Lig4',['../class_lig4.html#a7887e20e1244fedf6f8d613571809ff1',1,'Lig4']]],
  ['limpaconteudocasa_1',['limpaConteudoCasa',['../class_tabuleiro_damas.html#a8457b345539e7f057cd43679481c3821',1,'TabuleiroDamas']]],
  ['log_2',['log',['../structdoctest_1_1detail_1_1_result_builder.html#a2af75dd1d8db8d3aa949d78025854085',1,'doctest::detail::ResultBuilder::log()'],['../structdoctest_1_1detail_1_1_message_builder.html#a9bcc5d56e1764a7e07efebca55e43cce',1,'doctest::detail::MessageBuilder::log()']]],
  ['log_5fassert_3',['log_assert',['../structdoctest_1_1_i_reporter.html#a5bb54923eab233bb02f2fcfc178fa12a',1,'doctest::IReporter']]],
  ['log_5fmessage_4',['log_message',['../structdoctest_1_1_i_reporter.html#a2b2cb4f15aa7417d4903a0edc3147018',1,'doctest::IReporter']]]
];
