var searchData=
[
  ['p_0',['p',['../classdoctest_1_1_context.html#a1e22f778caf173478623e22546d7b493',1,'doctest::Context']]],
  ['parseargs_1',['parseArgs',['../classdoctest_1_1_context.html#a90b2f1bbf67ee4da8e8ff0cf7516a06a',1,'doctest::Context']]],
  ['partesatingidas_2',['partesAtingidas',['../class_barco.html#a4f5a86ebea7aac0d13dd40e75e8d3115',1,'Barco']]],
  ['pegajogada_3',['pegaJogada',['../class_batalha_naval.html#abd997fd552ff39cd92ad1cf13293c505',1,'BatalhaNaval::pegaJogada()'],['../class_lig4.html#a81d8e7c4bef6312c93e53ec29f6ee758',1,'Lig4::pegaJogada()'],['../class_reversi.html#a221d9aee6c82c80f591bc4f253ac98ce',1,'Reversi::pegaJogada()'],['../class_tabuleiro.html#a295c7f8cf7418b4135f94a118c8a7469',1,'Tabuleiro::pegaJogada()'],['../class_tabuleiro_damas.html#abb22b791877fd4d03b721b77f4840a55',1,'TabuleiroDamas::pegaJogada()']]],
  ['pegaposicaobarcos_4',['pegaPosicaoBarcos',['../class_batalha_naval.html#adb36b7094dd35287acf3520ddc2e352e',1,'BatalhaNaval']]],
  ['ponto_5',['Ponto',['../class_ponto.html',1,'Ponto'],['../class_ponto.html#a49b03b00e9ebc01c2011c25f6517b93b',1,'Ponto::Ponto()'],['../class_ponto.html#aa656c9a2a5f573f0bc631b89a0e0ea71',1,'Ponto::Ponto(int x, int y)']]],
  ['ponto_2ehpp_6',['ponto.hpp',['../ponto_8hpp.html',1,'']]],
  ['posicionabarcos_7',['posicionaBarcos',['../class_batalha_naval.html#aec279e8090b20914805fabdd397efd42',1,'BatalhaNaval']]],
  ['posicionado_8',['posicionado',['../class_barco.html#ad128a65cce624d7fb60fc3c4d8ff00e1',1,'Barco']]],
  ['posjogo_9',['posJogo',['../class_jogador.html#a7078fe6b6fb0da4966100ace7d713a24',1,'Jogador']]],
  ['preenchecoordenadas_10',['preencheCoordenadas',['../class_barco.html#a33bb451433efd463e00e9380f0e3babd',1,'Barco']]],
  ['ptr_11',['ptr',['../structdoctest_1_1_string_1_1view.html#a18a399abb1e4be67bcc6d6557837a98c',1,'doctest::String::view']]],
  ['pulajogada_12',['pulaJogada',['../class_reversi.html#af9f56e639bad17aed3606df6011152d5',1,'Reversi']]]
];
