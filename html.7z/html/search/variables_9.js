var searchData=
[
  ['jogador_0',['jogador',['../class_tabuleiro.html#a8b02006dfb29135c8c2d4396f1c5897c',1,'Tabuleiro']]]
];
