var searchData=
[
  ['x_0',['x',['../class_ponto.html#af1a31a22498a03ae6306f6e25e842095',1,'Ponto']]]
];
