var searchData=
[
  ['imprimetabuleiro_0',['imprimeTabuleiro',['../class_batalha_naval.html#a27248d59576f27d77c1459178dbeb7e6',1,'BatalhaNaval::imprimeTabuleiro()'],['../class_tabuleiro.html#a4ce5aa160c82779f953edd68b7b06be6',1,'Tabuleiro::imprimeTabuleiro()']]],
  ['instantiationhelper_1',['instantiationHelper',['../namespacedoctest_1_1detail.html#aad401b097a9af4df1d4a9d0911957c0f',1,'doctest::detail']]],
  ['invertejogador_2',['inverteJogador',['../class_batalha_naval.html#a2f5131af966acffb7440b4a7e0d53f21',1,'BatalhaNaval']]],
  ['isdebuggeractive_3',['isDebuggerActive',['../namespacedoctest_1_1detail.html#a013828c4e677241cc26aeea33f762710',1,'doctest::detail']]],
  ['isnan_4',['IsNaN',['../structdoctest_1_1_is_na_n.html#a47f3957c504f7d8bc40dd4014cce5ee1',1,'doctest::IsNaN']]],
  ['isonstack_5',['isOnStack',['../classdoctest_1_1_string.html#a3d0c1d8e0d27818235e0639f49d232e9',1,'doctest::String']]]
];
