var searchData=
[
  ['barco_0',['Barco',['../class_barco.html',1,'']]],
  ['basic_5fistream_1',['basic_istream',['../classstd_1_1basic__istream.html',1,'std']]],
  ['basic_5fostream_2',['basic_ostream',['../classstd_1_1basic__ostream.html',1,'std']]],
  ['batalhanaval_3',['BatalhaNaval',['../class_batalha_naval.html',1,'']]]
];
