var searchData=
[
  ['barco_0',['Barco',['../class_barco.html#aea54a1f00318af549e695999ccf08e38',1,'Barco::Barco()'],['../class_barco.html#a99cc8669abad6a2ecbec5faf75486120',1,'Barco::Barco(int tamanho, int id)']]],
  ['batalhanaval_1',['BatalhaNaval',['../class_batalha_naval.html#abd37f9b78e4d8fc029bd22b43220c26b',1,'BatalhaNaval::BatalhaNaval()'],['../class_batalha_naval.html#a970c6ec8c072cd1a3079e392e9d5a549',1,'BatalhaNaval::BatalhaNaval(int num_linhas, int num_colunas)']]],
  ['binary_5fassert_2',['binary_assert',['../structdoctest_1_1detail_1_1_result_builder.html#aa920a0617a26939d7adcd1ba2dec0e85',1,'doctest::detail::ResultBuilder::binary_assert()'],['../namespacedoctest_1_1detail.html#a1e295c708d2de0e47ac89c1632211159',1,'doctest::detail::binary_assert()']]]
];
