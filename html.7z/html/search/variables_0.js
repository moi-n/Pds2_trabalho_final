var searchData=
[
  ['abort_5fafter_0',['abort_after',['../structdoctest_1_1_context_options.html#a8ba5bfec2229bc2da9ab917f4bdee5e7',1,'doctest::ContextOptions']]],
  ['apelido_1',['apelido',['../class_jogador.html#a62da12f178990e2450b5e819d90825bd',1,'Jogador']]]
];
