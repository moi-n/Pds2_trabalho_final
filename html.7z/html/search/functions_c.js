var searchData=
[
  ['parseargs_0',['parseArgs',['../classdoctest_1_1_context.html#a90b2f1bbf67ee4da8e8ff0cf7516a06a',1,'doctest::Context']]],
  ['pegajogada_1',['pegaJogada',['../class_batalha_naval.html#abd997fd552ff39cd92ad1cf13293c505',1,'BatalhaNaval::pegaJogada()'],['../class_lig4.html#a81d8e7c4bef6312c93e53ec29f6ee758',1,'Lig4::pegaJogada()'],['../class_reversi.html#a221d9aee6c82c80f591bc4f253ac98ce',1,'Reversi::pegaJogada()'],['../class_tabuleiro.html#a295c7f8cf7418b4135f94a118c8a7469',1,'Tabuleiro::pegaJogada()'],['../class_tabuleiro_damas.html#abb22b791877fd4d03b721b77f4840a55',1,'TabuleiroDamas::pegaJogada()']]],
  ['pegaposicaobarcos_2',['pegaPosicaoBarcos',['../class_batalha_naval.html#adb36b7094dd35287acf3520ddc2e352e',1,'BatalhaNaval']]],
  ['ponto_3',['Ponto',['../class_ponto.html#a49b03b00e9ebc01c2011c25f6517b93b',1,'Ponto::Ponto()'],['../class_ponto.html#aa656c9a2a5f573f0bc631b89a0e0ea71',1,'Ponto::Ponto(int x, int y)']]],
  ['posicionabarcos_4',['posicionaBarcos',['../class_batalha_naval.html#aec279e8090b20914805fabdd397efd42',1,'BatalhaNaval']]],
  ['posjogo_5',['posJogo',['../class_jogador.html#a7078fe6b6fb0da4966100ace7d713a24',1,'Jogador']]],
  ['preenchecoordenadas_6',['preencheCoordenadas',['../class_barco.html#a33bb451433efd463e00e9380f0e3babd',1,'Barco']]]
];
