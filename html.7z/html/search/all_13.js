var searchData=
[
  ['unary_5fassert_0',['unary_assert',['../structdoctest_1_1detail_1_1_result_builder.html#a63a2a19638f4a761c70abd5563e2d23a',1,'doctest::detail::ResultBuilder::unary_assert()'],['../namespacedoctest_1_1detail.html#a0ffd8b760c2a9b355a1df02470fe2281',1,'doctest::detail::unary_assert()']]],
  ['underlying_5ftype_1',['underlying_type',['../structdoctest_1_1detail_1_1types_1_1underlying__type.html',1,'doctest::detail::types']]]
];
