var searchData=
[
  ['react_0',['react',['../structdoctest_1_1detail_1_1_result_builder.html#a03686f862471728c2980d72e02980213',1,'doctest::detail::ResultBuilder::react()'],['../structdoctest_1_1detail_1_1_message_builder.html#a3a65c5e39a0c04ae8e2a7c34997a2e4d',1,'doctest::detail::MessageBuilder::react()']]],
  ['registerexceptiontranslator_1',['registerExceptionTranslator',['../namespacedoctest.html#a8e23e6bb4c6982688652060dbe41385d',1,'doctest']]],
  ['registerexceptiontranslatorimpl_2',['registerExceptionTranslatorImpl',['../namespacedoctest_1_1detail.html#a3887426da16e0d12e6f0e270a767a6a5',1,'doctest::detail']]],
  ['registerreporter_3',['registerReporter',['../namespacedoctest.html#a9e878a811f7bf0a615b3a39de3004673',1,'doctest']]],
  ['registerreporterimpl_4',['registerReporterImpl',['../namespacedoctest_1_1detail.html#a828e011bb6028ab94eb14a3c7d8bd2c4',1,'doctest::detail']]],
  ['regtest_5',['regTest',['../namespacedoctest_1_1detail.html#a00f99edefb8490a8e2602d58c96431f4',1,'doctest::detail']]],
  ['reiniciaconteudotabuleiro_6',['reiniciaConteudoTabuleiro',['../class_batalha_naval.html#ad9012d42c10ec4bc803dc12eaa371122',1,'BatalhaNaval']]],
  ['removejogador_7',['removeJogador',['../class_jogador.html#a5dfb8a42549329b57c4a7f005e86c828',1,'Jogador']]],
  ['report_5fquery_8',['report_query',['../structdoctest_1_1_i_reporter.html#ae7e30d1c2cd332094c66d39bf3a85e52',1,'doctest::IReporter']]],
  ['reportercreator_9',['reporterCreator',['../namespacedoctest_1_1detail.html#ac78a52271e895d8485356c4516a18685',1,'doctest::detail']]],
  ['result_10',['Result',['../structdoctest_1_1detail_1_1_result.html#ae38382da1a2d2f8e33aebc7da15febc9',1,'doctest::detail::Result::Result()=default'],['../structdoctest_1_1detail_1_1_result.html#ae4d2e8633aedaffa31f5c8b8530f522c',1,'doctest::detail::Result::Result(bool passed, const String &amp;decomposition=String())']]],
  ['resultbuilder_11',['ResultBuilder',['../structdoctest_1_1detail_1_1_result_builder.html#a135e00690002d376f3d050700a635680',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type=&quot;&quot;, const String &amp;exception_string=&quot;&quot;)'],['../structdoctest_1_1detail_1_1_result_builder.html#ab55660e3aaa5d8fccbe19360f65bb1f3',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type, const Contains &amp;exception_string)']]],
  ['reversi_12',['Reversi',['../class_reversi.html#a73e3ca5c21b634f9c490b404d62f0e01',1,'Reversi']]],
  ['rfind_13',['rfind',['../classdoctest_1_1_string.html#a6e22f4f3820de5ffdf82e0acc6646759',1,'doctest::String']]],
  ['run_14',['run',['../classdoctest_1_1_context.html#a8059b137ef41cbe6c5d8160806a3cc63',1,'doctest::Context']]]
];
