var searchData=
[
  ['querydata_0',['QueryData',['../structdoctest_1_1_query_data.html',1,'doctest']]]
];
