var searchData=
[
  ['what_0',['what',['../class_tabuleiro_1_1saida_sistema.html#aa88ff33d5cdb8c933c38a497438ecc38',1,'Tabuleiro::saidaSistema']]]
];
