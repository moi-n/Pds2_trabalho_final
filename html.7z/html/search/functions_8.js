var searchData=
[
  ['jogadapossivel_0',['jogadaPossivel',['../class_reversi.html#ae4846352e7a07421c7cebb9b4c0c6e5d',1,'Reversi']]],
  ['jogador_1',['Jogador',['../class_jogador.html#a85bb56e9e90981e828e6199730c75b2d',1,'Jogador']]],
  ['jogodavelha_2',['JogodaVelha',['../class_jogoda_velha.html#ac69a08e983e1c2c958f6825450b145fb',1,'JogodaVelha::JogodaVelha()'],['../class_jogoda_velha.html#a8c7651ae97e9054b482bd2d1b76b9822',1,'JogodaVelha::JogodaVelha(int num_linhas, int num_colunas)']]]
];
