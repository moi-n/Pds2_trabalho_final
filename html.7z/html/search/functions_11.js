var searchData=
[
  ['verificacaptura_0',['verificaCaptura',['../class_tabuleiro_damas.html#a4bbb434b832c2600a4a4220fe56a7c73',1,'TabuleiroDamas']]],
  ['verificacoluna_1',['verificaColuna',['../class_reversi.html#a48752d01f4b16ef89bdf7611e738e2c0',1,'Reversi']]],
  ['verificadiagonal_2',['verificaDiagonal',['../class_reversi.html#affa226d04a93c34193dc28310b86def7',1,'Reversi']]],
  ['verificajogada_3',['verificaJogada',['../class_tabuleiro_damas.html#ace0cb511cf3479cb8f2af98590577f3c',1,'TabuleiroDamas']]],
  ['verificalinha_4',['verificaLinha',['../class_reversi.html#a000993146e8071ae7d9cbc014aa7960b',1,'Reversi']]]
];
