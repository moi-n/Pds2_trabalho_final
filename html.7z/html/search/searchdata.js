var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuvwxy~",
  1: "abcdefghijlmpqrstuv",
  2: "ds",
  3: "bcdgjlprt",
  4: "abcdefgijlmoprstuvw~",
  5: "abcdefghijlmnopqrstvxy",
  6: "afinorst",
  7: "e",
  8: "abcdefgilnrstwy",
  9: "o",
  10: "acdfgimrstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Namespaces",
  3: "Arquivos",
  4: "Funções",
  5: "Variáveis",
  6: "Definições de Tipos",
  7: "Enumerações",
  8: "Enumeradores",
  9: "Amigos",
  10: "Definições e Macros"
};

